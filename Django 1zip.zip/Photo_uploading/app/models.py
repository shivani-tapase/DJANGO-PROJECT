from django.db import models

# Create your models here.
class EmployeeModel(models.Model):
    Idno=models.IntegerField(primary_key=True)
    name=models.CharField(max_length=30)
    salary=models.FloatField()
    photo=models.ImageField(upload_to='Emp_images/')
    Address=models.TextField()