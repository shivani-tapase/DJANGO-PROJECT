from django.shortcuts import render,redirect
from app.models import EmployeeModel
# Create your views here.
def showIndex(request):
    return render(request,'index.html')

def save_emp(request):
    n=request.POST.get("t1")
    na=request.POST.get("t2")
    sa=request.POST.get("t3")
    img=request.FILES["t4"]
    add=request.POST.get("t5")
    EmployeeModel(Idno=n,name=na,salary=sa,photo=img,Address=add).save()
    return redirect("main")